import tweepy
import telegram

def main():
    #authenticate with telegram
    bot = telegram.Bot(token='YOUR_TELEGRAM_BOT_TOKEN')
    updates = bot.getUpdates()
    for update in updates:
        message = update.message.text
        #authenticate with twitter
        auth = tweepy.OAuthHandler("CONSUMER_KEY", "CONSUMER_SECRET")
        auth.set_access_token("ACCESS_TOKEN", "ACCESS_TOKEN_SECRET")
        api = tweepy.API(auth)
        api.update_status(message)

if __name__ == "__main__":
    main()
